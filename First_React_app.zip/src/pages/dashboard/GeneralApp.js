import { Box, Stack } from "@mui/material";
import React from "react";
import Conversation from "../../components/Conversation";

const GeneralApp = () => {
  return (
    <Stack direction={"row"} sx={{ width: "100%" }}>
      <Box
        sx={{
          height: "100%",
          width: "calc(100vw - 35%)",
          backgroundColor: "#fff",
        }}
      >
        <Conversation />

      </Box>
    </Stack>
  );
};

export default GeneralApp;
